# Gap Hero Banner Exercise

A mock, CMS-driven Hero Banner system built with Next.js, featuring multi-brand support, high-performance image optimization, and responsive fluid typography.

## 🚀 Key Features

- **Multi-Brand Architecture**: Supports both **GAP** and **Old Navy** branding with specific design tokens, layouts, and semantic themes.
- **Dynamic Content Variants**: Specialized implementations for **Image-based** (with call-to-actions) and **Color-based** (with navigation links) banners.
- **Performance Optimized**:
  - Integrated `next/image` for LCP optimization and automatic format selection.
  - Fluid typography using CSS `clamp()` for impactful headings across all devices.
  - Priority loading for critical above-the-fold content.
- **Resilient Data Layer**: Dedicated service layer with a corruption barrier (validation) for safe integration with CMS data.
- **Developer Experience**:
  - Comprehensive **Storybook** suite for component exploration.
  - 100% TypeScript coverage with strict union types.
  - Clean BEM-based SCSS structure.

  Key Strengths
  - Modern Stack: Next.js 16.1, React 19.2, Tailwind CSS v4, and TypeScript.
  - Component Architecture: The HeroBanner component is a highlight—it's polymorphic (handling 'image' vs. 'color'
    variants), themeable (Gap vs. Old Navy), and performance-optimized (using next/image with priority).
  - Hybrid Styling: cleverly combines Tailwind CSS for layout/utilities with SCSS Modules for complex, brand-specific
    component styles, utilizing CSS variables for easy theming.
  - Robust Data Layer: A dedicated service layer (bannerService.ts) with runtime validation (validateBanners) acts as a
    "corruption barrier" against malformed data.
  - Production Readiness: Includes comprehensive linting, formatting, and testing configurations (Vitest, Storybook,
    Husky).

## 📋 Requirements Fulfilled

- [x] Create flexible Hero Banner component with Image and Color variants.
- [x] Robust data fetching using a shared service layer and API routes.
- [x] Professional-grade documentation (JSDoc, Storybook, README).

### Extra Credit

- [x] Support multiple brands (Gap, Old Navy) with unique styling.
- [x] Implement optimized image rendering using Next.js Image component.
- [x] Ensure responsive design:
  - Vertical stacking of action buttons on mobile.
  - Progressive font scaling (larger mobile headers, premium desktop calc).
  - Maintained horizontal link layouts for navigation context.

## 🛠️ Getting Started

First, install dependencies:

```bash
npm install
```

Then, run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the live demo.

### Running Storybook

To explore the component library and brand variants:

```bash
npm run storybook
```

### Running Tests

To run the unit test suite:

```bash
npm run test
```

## 🏗️ Architecture

- **Modern Stack:** Built with Next.js 16.1, React 19.2, Tailwind CSS v4, and TypeScript.
- **Component Architecture:** The `HeroBanner` is a core example—polymorphic (supporting image and color variants), themeable (Gap and Old Navy), and performance-optimized using `next/image` with priority loading.
- **Hybrid Styling Approach:** Combines Tailwind CSS for layout and utilities with SCSS Modules for complex, brand-specific styles. CSS variables are used to enable flexible theming.
- **Robust Data Layer:** A dedicated service layer (`bannerService.ts`) with runtime validation (`validateBanners`) serves as a corruption barrier against malformed or unexpected data.
- **Production Readiness:** Includes comprehensive linting, formatting, and testing tooling, including Vitest, Storybook, and Husky.

---

_This project was developed as a technical exercise to demonstrate modern web development best practices, accessibility, and performance._
