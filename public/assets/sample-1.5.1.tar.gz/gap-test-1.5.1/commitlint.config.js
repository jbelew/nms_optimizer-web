const config = { extends: ["@commitlint/config-conventional"] };
export default config;
