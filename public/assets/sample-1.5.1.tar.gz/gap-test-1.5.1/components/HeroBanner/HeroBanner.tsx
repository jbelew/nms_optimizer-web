"use client";

import React from "react";
import NextImage from "next/image";

import { useBrand } from "@/context/BrandContext";
import { HeroBannerProps, ImageBannerProps } from "@/types/banner";

import HeroBannerColor from "./HeroBanner.Color";
import HeroBannerImage from "./HeroBanner.Image";
import { buildBannerClasses, buildBannerStyle } from "./HeroBanner.Utils";

import "./HeroBanner.Base.scss";
import "./HeroBanner.Brand.Gap.scss";
import "./HeroBanner.Brand.OldNavy.scss";

const BASE_CLASS = "banner";

type HeroBannerPropsWithHeading = HeroBannerProps & {
	headingLevel?: "h1" | "h2" | "h3";
};

interface HeroBannerComponent extends React.FC<HeroBannerPropsWithHeading> {
	Image: typeof HeroBannerImage;
	Color: typeof HeroBannerColor;
}

/**
 * A versatile hero banner component that renders either an image-based or color-based variant.
 * Designed to be CMS-driven, supporting multiple brands with specific layouts and styling through SCSS modules.
 * @component
 * @param {HeroBannerPropsWithHeading} props - The configuration props for the banner variant
 * @returns {React.ReactElement} The rendered hero banner section
 */
const HeroBanner: HeroBannerComponent = (props) => {
	const contextBrand = useBrand();
	const brand = props.brand || contextBrand || "gap"; // Fallback to gap if no context or prop

	const { headingLevel: HeadingTag = "h1" } = props as HeroBannerPropsWithHeading;
	const style = buildBannerStyle(props);
	const className = buildBannerClasses(BASE_CLASS, props.type, brand as string);
	const isImageVariant = props.type === "image";

	return (
		<section className={className} style={style} data-brand={brand}>
			{isImageVariant && (
				<div className={`${BASE_CLASS}__image-wrapper`}>
					<NextImage
						src={(props as ImageBannerProps).backgroundImage}
						alt={props.heading}
						fill
						priority
						// unoptimized
						className={`${BASE_CLASS}__image`}
						sizes="(max-width: 768px) 100vw, 50vw"
					/>
				</div>
			)}
			<div className={`${BASE_CLASS}__content`}>
				<HeadingTag className={`${BASE_CLASS}__heading`}>{props.heading}</HeadingTag>

				{isImageVariant && (
					<HeroBanner.Image baseClass={BASE_CLASS} {...(props as ImageBannerProps)} />
				)}

				{!isImageVariant && <HeroBanner.Color baseClass={BASE_CLASS} {...props} />}
			</div>
		</section>
	);
};

/* --------------------------------------------------------------------------
   EXTENSION NOTES:
   To extend this component for production-grade features:
   
   1. ART DIRECTION: 
      Modified the schema to support `AssetSet { desktop: string, mobile?: string }`.
      Use the `NextImage` component's `src` logic or a <picture> tag with different 
      sources to swap assets based on viewport size.
   
   2. ANALYTICS:
      Pass an `analytics` object from the CMS and attach `onClick` handlers 
      to buttons call your global tracking service (e.g., GTM/Segment).
   
   3. ACCESSIBILITY:
      Introduce a dedicated `altText` field in the schema to provide 
      richer context than just the heading.
   -------------------------------------------------------------------------- */

HeroBanner.Image = HeroBannerImage;
HeroBanner.Color = HeroBannerColor;
HeroBanner.displayName = "HeroBanner";

export default HeroBanner;
