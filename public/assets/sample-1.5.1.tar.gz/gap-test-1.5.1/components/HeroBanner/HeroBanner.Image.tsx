import React from "react";

import { ImageBannerProps } from "@/types/banner";

interface HeroBannerImageProps extends ImageBannerProps {
	baseClass: string;
}

/**
 * Internal sub-component for rendering the image-based hero variant.
 * Handles the display of the optimized background image wrapper, subheading, and action buttons.
 * @component
 * @param {HeroBannerImageProps} props - The image variant specific props
 * @returns {React.ReactElement} The image banner content fragment
 */
const Component: React.FC<HeroBannerImageProps> = ({ baseClass, subHeading, actions }) => (
	<>
		{subHeading && <p className={`${baseClass}__subheading`}>{subHeading}</p>}
		{actions.length > 0 && (
			<div className={`${baseClass}__actions`}>
				{actions.map((action, index) => (
					<a
						key={index}
						href={action.href}
						className={`${baseClass}__button ${baseClass}__button--${action.variant}`}
					>
						{action.label}
					</a>
				))}
			</div>
		)}
	</>
);

Component.displayName = "HeroBanner.Image";
export default Component;
