import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { BannerType, BrandName } from "@/types/banner";

import "@testing-library/jest-dom";

import { type ColorBannerProps, type ImageBannerProps } from "@/types/banner";

import HeroBanner from ".";

describe("HeroBanner", () => {
	describe("Color Variant", () => {
		const defaultProps: ColorBannerProps = {
			id: "test-banner",
			type: BannerType.Color,
			brand: BrandName.Gap,
			heading: "Test Heading",
			backgroundColor: "#ffffff",
			links: [],
		};

		it("should render heading", () => {
			render(<HeroBanner {...defaultProps} />);
			expect(screen.getByRole("heading", { name: "Test Heading" })).toBeInTheDocument();
		});

		it("should apply brand attribute", () => {
			const { container } = render(<HeroBanner {...defaultProps} />);
			expect(container.querySelector('[data-brand="gap"]')).toBeInTheDocument();
		});

		it("should render with links", () => {
			const props: ColorBannerProps = {
				...defaultProps,
				links: [
					{ label: "Link 1", href: "/link-1" },
					{ label: "Link 2", href: "/link-2" },
				],
			};
			render(<HeroBanner {...props} />);
			expect(screen.getByText("Link 1")).toBeInTheDocument();
			expect(screen.getByText("Link 2")).toBeInTheDocument();
		});

		it("should handle empty links array", () => {
			render(<HeroBanner {...defaultProps} />);
			const links = screen.queryAllByRole("link");
			expect(links).toHaveLength(0);
		});

		it("should handle unicode in heading", () => {
			const props: ColorBannerProps = {
				...defaultProps,
				heading: "🎉 Test 中文",
			};
			render(<HeroBanner {...props} />);
			expect(screen.getByText("🎉 Test 中文")).toBeInTheDocument();
		});

		it("should handle long heading text", () => {
			const longHeading = "A".repeat(500);
			const props: ColorBannerProps = {
				...defaultProps,
				heading: longHeading,
			};
			render(<HeroBanner {...props} />);
			expect(screen.getByText(longHeading)).toBeInTheDocument();
		});
	});

	describe("Image Variant", () => {
		const defaultProps: ImageBannerProps = {
			id: "test-banner-image",
			type: BannerType.Image,
			brand: BrandName.Gap,
			heading: "Test Image Heading",
			backgroundImage: "/img/image-1.avif",
			actions: [],
		};

		it("should render heading", () => {
			render(<HeroBanner {...defaultProps} />);
			expect(screen.getByRole("heading", { name: "Test Image Heading" })).toBeInTheDocument();
		});

		it("should apply brand attribute", () => {
			const { container } = render(<HeroBanner {...defaultProps} />);
			expect(container.querySelector('[data-brand="gap"]')).toBeInTheDocument();
		});

		it("should render subHeading when provided", () => {
			const props: ImageBannerProps = {
				...defaultProps,
				subHeading: "This is a subheading",
			};
			render(<HeroBanner {...props} />);
			expect(screen.getByText("This is a subheading")).toBeInTheDocument();
		});

		it("should not render subHeading when not provided", () => {
			render(<HeroBanner {...defaultProps} />);
			expect(screen.queryByText(/subheading|sub-heading/i)).not.toBeInTheDocument();
		});

		it("should render actions with correct variants", () => {
			const props: ImageBannerProps = {
				...defaultProps,
				actions: [
					{ label: "Primary", href: "/primary", variant: "primary" },
					{ label: "Secondary", href: "/secondary", variant: "secondary" },
				],
			};
			render(<HeroBanner {...props} />);
			expect(screen.getByText("Primary")).toBeInTheDocument();
			expect(screen.getByText("Secondary")).toBeInTheDocument();
		});

		it("should handle empty actions array", () => {
			render(<HeroBanner {...defaultProps} />);
			const actions = screen.queryAllByRole("link");
			expect(actions).toHaveLength(0);
		});

		it("should handle many actions", () => {
			const props: ImageBannerProps = {
				...defaultProps,
				actions: Array.from({ length: 10 }, (_, i) => ({
					label: `Action ${i}`,
					href: `/action-${i}`,
					variant: i % 2 === 0 ? "primary" : "secondary",
				})),
			};
			render(<HeroBanner {...props} />);
			expect(screen.getByText("Action 0")).toBeInTheDocument();
			expect(screen.getByText("Action 9")).toBeInTheDocument();
		});
	});
});
