import React from "react";

import { ColorBannerProps } from "@/types/banner";

interface HeroBannerColorProps extends ColorBannerProps {
	baseClass: string;
}

/**
 * Internal sub-component for rendering the color-based hero variant.
 * Handles the display of the background color and navigation links.
 * @component
 * @param {HeroBannerColorProps} props - The color variant specific props
 * @returns {React.ReactElement} The color banner content fragment
 */
const Component: React.FC<HeroBannerColorProps> = ({ baseClass, links }) => (
	<>
		{links.length > 0 && (
			<div className={`${baseClass}__links`}>
				{links.map((link, index) => (
					<a key={index} href={link.href} className={`${baseClass}__link`}>
						{link.label}
					</a>
				))}
			</div>
		)}
	</>
);

Component.displayName = "HeroBanner.Color";
export default Component;
