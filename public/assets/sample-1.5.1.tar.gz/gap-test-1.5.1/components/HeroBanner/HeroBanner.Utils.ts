import { ColorBannerProps, ImageBannerProps } from "@/types/banner";

/**
 * Builds CSS style properties for a banner based on its type.
 * @param {ImageBannerProps | ColorBannerProps} props - The banner props
 * @returns {CSSProperties} The CSS style object for the banner
 */
export const buildBannerStyle = (
	props: ImageBannerProps | ColorBannerProps
): React.CSSProperties => {
	const style: React.CSSProperties = {};

	if (props.type === "color") {
		const colorProps = props as ColorBannerProps;
		style.backgroundColor = colorProps.backgroundColor;
	}

	return style;
};

/**
 * Builds CSS class names for a banner based on its type and brand.
 * @param {string} baseClass - The base CSS class name
 * @param {string} type - The banner type (e.g., 'image', 'color')
 * @param {string} brand - The brand name (e.g., 'gap', 'oldnavy')
 * @returns {string} The combined CSS class names
 */
export const buildBannerClasses = (baseClass: string, type: string, brand: string): string => {
	return `${baseClass} ${baseClass}--${type} ${baseClass}--${brand}`.trim();
};
