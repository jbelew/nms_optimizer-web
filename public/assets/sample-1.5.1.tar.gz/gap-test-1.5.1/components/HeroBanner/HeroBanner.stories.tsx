import type { Meta, StoryObj } from "@storybook/react";

import { BannerType, BrandName } from "@/types/banner";

import HeroBanner from "./index";

import "./HeroBanner.Base.scss";
import "./HeroBanner.Brand.Gap.scss";
import "./HeroBanner.Brand.OldNavy.scss";

const meta: Meta<typeof HeroBanner> = {
	component: HeroBanner,
	title: "Components/HeroBanner",
	tags: ["autodocs"],
	parameters: {
		docs: {
			description: {
				component:
					"A high-impact, CMS-driven Hero Banner supporting both Image and Color variants with brand-specific styling overrides.",
			},
		},
	},
	args: {
		id: "banner-default",
		heading: "Default Banner",
		brand: BrandName.Gap,
		type: BannerType.Color,
		backgroundColor: "#00418c",
		links: [],
		backgroundImage: "/img/image-1.avif",
		actions: [],
	} as never,
	argTypes: {
		type: {
			control: "inline-radio",
			options: [BannerType.Image, BannerType.Color],
			description: "Switch between visual variants (Background Image vs Background Color)",
		},
		brand: {
			control: "radio",
			options: [BrandName.Gap, BrandName.OldNavy],
			description: "The brand name",
		},
		backgroundColor: {
			control: "color",
			if: { arg: "type", eq: BannerType.Color },
		},
		backgroundImage: {
			control: "text",
			if: { arg: "type", eq: BannerType.Image },
		},
		links: {
			if: { arg: "type", eq: BannerType.Color },
		},
		actions: {
			if: { arg: "type", eq: BannerType.Image },
		},
		subHeading: {
			if: { arg: "type", eq: BannerType.Image },
		},
	},
};

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Color banner variant displaying a promotional message with links.
 */
export const ColorBanner: Story = {
	args: {
		id: "banner-color",
		type: BannerType.Color,
		brand: BrandName.Gap,
		heading: "Gap Winter Clearance Sale",
		backgroundColor: "#00418c",
		links: [
			{ label: "View Details", href: "#details" },
			{ label: "Exclusions", href: "#exclusions" },
		],
	} as never,
};

/**
 * Image banner variant with subheading and action buttons.
 */
export const ImageBanner: Story = {
	args: {
		id: "banner-image",
		type: BannerType.Image,
		brand: BrandName.Gap,
		heading: "Season's Best Styles",
		subHeading: "Shop the latest arrivals for the whole family",
		backgroundImage: "/img/image-1.avif",
		actions: [
			{ label: "Men", href: "/men", variant: "primary" },
			{ label: "Women", href: "/women", variant: "primary" },
			{ label: "Kids", href: "/kids", variant: "primary" },
			{ label: "Baby", href: "/baby", variant: "primary" },
		],
	} as never,
};

/**
 * Old Navy branded color banner.
 */
export const OldNavyColorBanner: Story = {
	args: {
		id: "banner-oldnavy-color",
		type: BannerType.Color,
		brand: BrandName.OldNavy,
		heading: "Old Navy Big Sale",
		backgroundColor: "#EF411E",
		links: [
			{ label: "Learn More", href: "#details" },
			{ label: "Shop Now", href: "#shop" },
		],
	} as never,
};

/**
 * Old Navy branded image banner.
 */
export const OldNavyImageBanner: Story = {
	args: {
		id: "banner-oldnavy-image",
		type: BannerType.Image,
		brand: BrandName.OldNavy,
		heading: "Season Finale",
		backgroundImage: "/img/image-3.avif",
		actions: [
			{ label: "Men", href: "/men", variant: "primary" },
			{ label: "Women", href: "/women", variant: "primary" },
			{ label: "Boys", href: "/kids", variant: "primary" },
			{ label: "Girls", href: "/baby", variant: "primary" },
		],
	} as never,
};

/**
 * Color banner with minimal links for accessibility testing.
 */
export const ColorBannerMinimal: Story = {
	args: {
		id: "banner-minimal",
		type: BannerType.Color,
		brand: BrandName.Gap,
		heading: "Limited Time Offer",
		backgroundColor: "#f9a1ed",
		links: [],
	} as never,
};

/**
 * Image banner with no subheading or actions.
 */
export const ImageBannerMinimal: Story = {
	args: {
		id: "banner-image-minimal",
		type: BannerType.Image,
		brand: BrandName.Gap,
		heading: "New Collections Available",
		backgroundImage: "/img/image-1.avif",
		actions: [],
	} as never,
};
