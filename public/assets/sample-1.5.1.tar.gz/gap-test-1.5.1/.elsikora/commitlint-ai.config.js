const config = {
	maxRetries: 3,
	mode: "auto",
	model: "gemini-2.5-flash",
	provider: "google",
	validationMaxRetries: 3,
};
export default config;
