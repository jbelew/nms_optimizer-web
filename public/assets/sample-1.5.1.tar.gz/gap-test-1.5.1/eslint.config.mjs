// For more info, see https://github.com/storybookjs/eslint-plugin-storybook#configuration-flat-config-format
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
import jsdoc from "eslint-plugin-jsdoc";
import storybook from "eslint-plugin-storybook";
import { defineConfig, globalIgnores } from "eslint/config";

const eslintConfig = defineConfig([
	...nextVitals,
	...nextTs,
	{
		plugins: {
			jsdoc,
		},
		rules: {
			"jsdoc/require-description": "warn",
			"jsdoc/require-param-description": "warn",
			"jsdoc/require-returns-description": "warn",
			"jsdoc/no-undefined-types": [
				"warn",
				{
					definedTypes: [
						"React",
						"ReactNode",
						"JSX",
						"Element",
						"CSSProperties",
						"ReactElement",
						"ReactFC",
						"Readonly",
					],
				},
			],
			"jsdoc/require-jsdoc": [
				"warn",
				{
					publicOnly: true,
					require: {
						FunctionDeclaration: true,
						MethodDefinition: true,
						ClassDeclaration: true,
						ArrowFunctionExpression: true,
						FunctionExpression: true,
					},
				},
			],
		},
	},
	{
		files: ["**/*.stories.{ts,tsx}"],
		plugins: {
			storybook,
		},
		rules: {
			"storybook/await-interactions": "error",
			"storybook/context-in-play-function": "error",
			"storybook/default-exports": "error",
		},
	},
	// Override default ignores of eslint-config-next.
	globalIgnores([
		// Default ignores of eslint-config-next:
		".next/**",
		"out/**",
		"build/**",
		"next-env.d.ts",
	]),
]);

export default eslintConfig;
