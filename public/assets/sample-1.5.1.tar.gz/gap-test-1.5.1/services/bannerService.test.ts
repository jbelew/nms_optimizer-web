import { describe, expect, it } from "vitest";

import { BannerType, BrandName } from "@/types/banner";

import { getHeroBanners } from "./bannerService";

describe("bannerService", () => {
	describe("getHeroBanners", () => {
		it("should return an array of banners", async () => {
			const banners = await getHeroBanners();

			expect(Array.isArray(banners)).toBe(true);
		});

		it("should return banners with required properties", async () => {
			const banners = await getHeroBanners();

			banners.forEach((banner) => {
				expect(banner).toHaveProperty("id");
				expect(banner).toHaveProperty("type");
				expect(banner).toHaveProperty("brand");
				expect(banner).toHaveProperty("heading");
			});
		});

		it("should return at least 4 banners", async () => {
			const banners = await getHeroBanners();

			expect(banners.length).toBeGreaterThanOrEqual(4);
		});

		it("should include banners of both color and image types", async () => {
			const banners = await getHeroBanners();

			const types = new Set(banners.map((b) => b.type));
			expect(types.has(BannerType.Color)).toBe(true);
			expect(types.has(BannerType.Image)).toBe(true);
		});

		it("should include banners from both gap and oldnavy brands", async () => {
			const banners = await getHeroBanners();

			const brands = new Set(banners.map((b) => b.brand));
			expect(brands.has(BrandName.Gap)).toBe(true);
			expect(brands.has(BrandName.OldNavy)).toBe(true);
		});

		it("should have valid color banner structure", async () => {
			const banners = await getHeroBanners();

			const colorBanners = banners.filter((b) => b.type === BannerType.Color);
			colorBanners.forEach((banner) => {
				expect(banner).toHaveProperty("backgroundColor");
				expect(banner).toHaveProperty("links");
				expect(Array.isArray(banner.links)).toBe(true);
			});
		});

		it("should have valid image banner structure", async () => {
			const banners = await getHeroBanners();

			const imageBanners = banners.filter((b) => b.type === BannerType.Image);
			imageBanners.forEach((banner) => {
				expect(banner).toHaveProperty("backgroundImage");
				expect(banner).toHaveProperty("actions");
				expect(Array.isArray(banner.actions)).toBe(true);
			});
		});

		it("should have unique banner ids", async () => {
			const banners = await getHeroBanners();

			const ids = banners.map((b) => b.id);
			const uniqueIds = new Set(ids);
			expect(uniqueIds.size).toBe(ids.length);
		});

		it("should have non-empty headings", async () => {
			const banners = await getHeroBanners();

			banners.forEach((banner) => {
				expect(banner.heading).toBeTruthy();
				expect(typeof banner.heading).toBe("string");
				expect(banner.heading.length).toBeGreaterThan(0);
			});
		});

		it("should return a resolved promise", async () => {
			const result = getHeroBanners();

			expect(result instanceof Promise).toBe(true);
			const banners = await result;
			expect(banners).toBeDefined();
		});
	});
});
