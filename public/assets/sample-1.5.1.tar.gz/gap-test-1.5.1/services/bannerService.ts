import type { HeroBannerProps } from "@/types/banner";

import { BannerType, BrandName } from "@/types/banner";

/**
 * Mock data containing hero banners for different brands and types.
 * Includes both image and color variants with actions/links.
 */
/**
 * Mock data containing hero banners for different brands and types.
 * Expanded to support multi-set layouts.
 */
const mockBanners: HeroBannerProps[] = [
	{
		id: "gap-1",
		type: BannerType.Image,
		brand: BrandName.Gap,
		heading: "GAP: Winter Essentials",
		subHeading: "Stay warm with our latest organic cotton collection",
		backgroundImage: "/img/image-1.avif",
		actions: [
			{ label: "Men", href: "#", variant: "primary" },
			{ label: "Women", href: "#", variant: "primary" },
		],
	},
	{
		id: "on-1",
		type: BannerType.Image,
		brand: BrandName.OldNavy,
		heading: "Big Family Sale",
		subHeading: "Matching pajamas for everyone",
		backgroundImage: "/img/image-3.avif",
		actions: [
			{ label: "Boys", href: "#", variant: "primary" },
			{ label: "Girls", href: "#", variant: "primary" },
		],
	},
	{
		id: "gap-2",
		type: BannerType.Color,
		brand: BrandName.Gap,
		heading: "GAP: 40% off Everything!",
		backgroundColor: "#002a5f",
		links: [
			{ label: "details", href: "#" },
			{ label: "exclusions", href: "#" },
		],
	},
	{
		id: "on-2",
		type: BannerType.Color,
		brand: BrandName.OldNavy,
		heading: "Old Navy: $10 Hoodies",
		backgroundColor: "#EF411E",
		links: [
			{ label: "details", href: "#" },
			{ label: "exclusions", href: "#" },
		],
	},
];

/**
 * Validates the raw banner data structure against the expected HeroBannerProps.
 */
function validateBanners(data: unknown): HeroBannerProps[] {
	if (!Array.isArray(data)) throw new Error("Invalid banner data: expected array");

	return data.map((banner, index) => {
		if (!banner.id || !banner.type || !banner.heading) {
			throw new Error(`Invalid banner data at index ${index}: missing required fields`);
		}
		return banner as HeroBannerProps;
	});
}

/**
 * Retrieves hero banners, optionally filtered by brand.
 * Simulates a REST API request (e.g., GET /api/banners?brand=gap).
 * @async
 * @param {BrandName} [brand] - The brand to filter by
 * @returns {Promise<HeroBannerProps[]>} A promise that resolves to an array of hero banner objects
 */
export async function getHeroBanners(brand?: BrandName): Promise<HeroBannerProps[]> {
	try {
		// Simulate async data retrieval and filtering logic
		let data = await Promise.resolve(mockBanners);

		if (brand) {
			data = data.filter((b) => b.brand === brand);
		}

		return validateBanners(data);
	} catch (error) {
		console.error("Service Error:", error);
		throw error;
	}
}
