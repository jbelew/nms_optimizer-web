## [1.5.1](https://github.com/jbelew/gap-test/compare/v1.5.0...v1.5.1) (2026-01-07)


### Bug Fixes

* **prettier:** standardize code formatting, linting, and development tooling configurations ([868577f](https://github.com/jbelew/gap-test/commit/868577fc32c60e9af2def57df424e0a5c8506509))

# [1.5.0](https://github.com/jbelew/gap-test/compare/v1.4.0...v1.5.0) (2026-01-07)


### Features

* **system:** enhance Banner System Robustness and Architectural Clarity ([d71eaf0](https://github.com/jbelew/gap-test/commit/d71eaf0dd7d3e8b26513de03abfaf6d0bafe188c))

# [1.4.0](https://github.com/jbelew/gap-test/compare/v1.3.0...v1.4.0) (2026-01-06)


### Features

* **storybook:** add Storybook with a11y and Vitest integration ([d2f7e24](https://github.com/jbelew/gap-test/commit/d2f7e2496b4ba4fe70a4cf3b58399becf7b9a37a))

# [1.3.0](https://github.com/jbelew/gap-test/compare/v1.2.0...v1.3.0) (2026-01-06)


### Features

* Integrate Next.js Image into hero banners, add app-level loading and error UIs, and validate banner data. ([70c87f5](https://github.com/jbelew/gap-test/commit/70c87f5cad82cd565614664059a318df7cdd3174))

# [1.2.0](https://github.com/jbelew/gap-test/compare/v1.1.0...v1.2.0) (2026-01-06)


### Features

* **changelog:** Added automated changelog generation ([6592120](https://github.com/jbelew/gap-test/commit/65921200025cd8959bdee69c40e3ce4f4627f788))
