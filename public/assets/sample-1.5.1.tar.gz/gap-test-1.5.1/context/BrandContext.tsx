"use client";

import React, { createContext, useContext } from "react";

import { BrandName } from "@/types/banner";

const BrandContext = createContext<BrandName | undefined>(undefined);

/**
 * Provider component that wraps sections to provide a brand context.
 */
export const BrandProvider: React.FC<{ brand: BrandName; children: React.ReactNode }> = ({
	brand,
	children,
}) => {
	return <BrandContext.Provider value={brand}>{children}</BrandContext.Provider>;
};

/**
 * Hook to consume the brand context.
 */
export const useBrand = () => useContext(BrandContext);
