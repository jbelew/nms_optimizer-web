import React from "react";
import { render, renderHook } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { BrandName } from "@/types/banner";

import { BrandProvider, useBrand } from "./BrandContext";

describe("BrandContext", () => {
	it("provides the correct brand value to its children", () => {
		const TestComponent = () => {
			const brand = useBrand();
			return <div data-testid="brand-value">{brand}</div>;
		};

		const { getByTestId } = render(
			<BrandProvider brand={BrandName.Gap}>
				<TestComponent />
			</BrandProvider>
		);

		expect(getByTestId("brand-value").textContent).toBe(BrandName.Gap);
	});

	it("works with the useBrand hook", () => {
		const wrapper = ({ children }: { children: React.ReactNode }) => (
			<BrandProvider brand={BrandName.OldNavy}>{children}</BrandProvider>
		);

		const { result } = renderHook(() => useBrand(), { wrapper });

		expect(result.current).toBe(BrandName.OldNavy);
	});

	it("returns undefined when used outside of BrandProvider", () => {
		const { result } = renderHook(() => useBrand());

		expect(result.current).toBeUndefined();
	});
});
