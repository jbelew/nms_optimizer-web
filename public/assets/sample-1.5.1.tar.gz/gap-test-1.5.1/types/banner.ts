/**
 * Supported banner variants.
 */
export enum BannerType {
	Image = "image",
	Color = "color",
}

/**
 * Supported brand names.
 */
export enum BrandName {
	Gap = "gap",
	OldNavy = "oldnavy",
}

/**
 * Represents a call-to-action button for image banners.
 */
export interface Action {
	label: string;
	href: string;
	variant: "primary" | "secondary";
}

/**
 * Represents a navigation link for color banners.
 */
export interface Link {
	label: string;
	href: string;
}

/**
 * Base banner properties shared across all variants.
 */
interface BannerBase {
	id: string;
	brand: BrandName;
	heading: string;
}

/**
 * Props specific to the image-based hero banner variant.
 */
export interface ImageBannerProps extends BannerBase {
	type: BannerType.Image;
	subHeading?: string;
	backgroundImage: string;
	actions: Action[];
}

/**
 * Props specific to the color-based hero banner variant.
 */
export interface ColorBannerProps extends BannerBase {
	type: BannerType.Color;
	backgroundColor: string;
	links: Link[];
}

/**
 * Union type representing any valid hero banner variant.
 * Used for component dispatching and service responses.
 *
 * EXTENSION NOTE: This schema can be extended to support high-scale CMS needs:
 * - Art Direction: Change `backgroundImage: string` to an object with `desktop` and `mobile` URLs.
 * - Analytics: Add `analytics?: { id: string; name: string }` to track CTR and impressions.
 * - Accessibility: Add `ariaLabel` or `altText` overrides for screen readers.
 */
export type HeroBannerProps = ImageBannerProps | ColorBannerProps;
