import { NextResponse } from "next/server";

import { getHeroBanners } from "@/services/bannerService";

/**
 * Retrieves all available hero banners.
 * @returns {Promise<NextResponse>} JSON response containing an array of HeroBannerProps
 */
export async function GET() {
	const banners = await getHeroBanners();
	return NextResponse.json(banners);
}
