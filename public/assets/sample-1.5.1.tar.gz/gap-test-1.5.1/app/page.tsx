import HeroBanner from "@/components/HeroBanner";
import { BrandProvider } from "@/context/BrandContext";
import { getHeroBanners } from "@/services/bannerService";
import { BrandName } from "@/types/banner";

/**
 * Home page component that displays hero banners in three distinct sections:
 * 1. GAP Brand Section (Using React Context)
 * 2. Old Navy Brand Section (Using React Context)
 * 3. Mixed Collection (max 4)
 */
export default async function Home() {
	// Simulate parallel fetches from a "REST API"
	const [gapBanners, onBanners, mixedBanners] = await Promise.all([
		getHeroBanners(BrandName.Gap),
		getHeroBanners(BrandName.OldNavy),
		getHeroBanners(), // All brands mixed
	]);

	return (
		<main className="min-h-screen space-y-16 p-8">
			{/* Section 1: GAP Section (Demoing React Context Wrapper) */}
			<BrandProvider brand={BrandName.Gap}>
				<section data-brand="gap" className="space-y-8">
					<h2 className="border-b pb-2 text-2xl font-bold tracking-widest uppercase">
						Gap Context Wrapper
					</h2>
					<div className="grid grid-cols-1 gap-8 md:grid-cols-2">
						{gapBanners.map((banner, index) => (
							<HeroBanner key={banner.id} {...banner} headingLevel={index === 0 ? "h2" : "h3"} />
						))}
					</div>
				</section>
			</BrandProvider>

			{/* Section 2: Old Navy Section (Demoing React Context Wrapper) */}
			<BrandProvider brand={BrandName.OldNavy}>
				<section data-brand="oldnavy" className="space-y-8">
					<h2 className="border-b pb-2 text-2xl font-bold tracking-widest uppercase">
						Old Navy Context Wrapper
					</h2>
					<div className="grid grid-cols-1 gap-8 md:grid-cols-2">
						{onBanners.map((banner, index) => (
							<HeroBanner key={banner.id} {...banner} headingLevel={index === 0 ? "h2" : "h3"} />
						))}
					</div>
				</section>
			</BrandProvider>

			{/* Section 3: Mixed Selection (Direct Props Example) */}
			<section className="space-y-8">
				<h2 className="border-b pb-2 text-2xl font-bold tracking-widest uppercase">
					Mixed Contexts
				</h2>
				<div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
					{mixedBanners.slice(0, 4).map((banner) => (
						<HeroBanner key={`mixed-${banner.id}`} {...banner} headingLevel="h3" />
					))}
				</div>
			</section>
		</main>
	);
}
