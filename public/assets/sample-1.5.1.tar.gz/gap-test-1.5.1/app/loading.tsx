/**
 * Loading component for the application.
 */
export default function Loading() {
	return (
		<main className="min-h-screen p-8">
			<div className="grid grid-cols-1 gap-8 md:grid-cols-2">
				{[1, 2, 3, 4].map((i) => (
					<div
						key={i}
						className="aspect-square animate-pulse rounded-lg bg-gray-200"
						aria-hidden="true"
					/>
				))}
			</div>
		</main>
	);
}
