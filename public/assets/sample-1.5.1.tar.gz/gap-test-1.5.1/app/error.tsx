"use client";

import { useEffect } from "react";

/**
 * Error boundary component for the application.
 * @param {Object} props - Component props
 * @param {Error} props.error - The error object
 * @param {Function} props.reset - Function to reset the error boundary
 */
export default function Error({
	error,
	reset,
}: {
	error: Error & { digest?: string };
	reset: () => void;
}) {
	useEffect(() => {
		console.error(error);
	}, [error]);

	return (
		<main className="flex min-h-screen flex-col items-center justify-center p-8 text-center">
			<h2 className="mb-4 text-2xl font-bold">Something went wrong!</h2>
			<p className="mb-8 text-gray-600">
				We&apos;re having trouble loading the banners. Please try again.
			</p>
			<button
				onClick={() => reset()}
				className="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
			>
				Try again
			</button>
		</main>
	);
}
